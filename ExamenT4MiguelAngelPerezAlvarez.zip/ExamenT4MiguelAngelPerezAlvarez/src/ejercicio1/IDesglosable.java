package ejercicio1;

public interface IDesglosable {
	
	double calcularIva(double iva);

}
