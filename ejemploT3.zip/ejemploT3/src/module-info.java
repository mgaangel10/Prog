/**
 * 
 */
/**
 * @author Admin
 *
 */
module ejemploT3 {
}