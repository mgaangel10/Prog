 package ejemploarraybi;

import java.util.Random;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fila=5,colum=5;
		int hasta=10,desde=1;
		Random num=new Random(System.nanoTime());
		int [] [] mitabla=new int[fila][colum];
		for (int i = 0; i < mitabla.length; i++) {
			for (int j = 0; j < mitabla[i].length; j++) {
				mitabla[i][j]= num.nextInt(hasta-desde+1)+desde;
				
			}
		}
		for (int i = 0; i < mitabla.length; i++) {
			for (int j = 0; j < mitabla[i].length; j++) {
				System.out.print(mitabla[i][j]+"\t");
				}
			System.out.println(" ");
		}
		
	}

}
