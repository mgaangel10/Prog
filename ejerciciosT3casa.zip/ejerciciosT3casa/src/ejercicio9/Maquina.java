package ejercicio9;

public class Maquina {
	
}
