package ejercicio3L2;

import java.util.Arrays;





public class Vendedor {
	
	private  Movil  moviles [];
	private int totalV;
	
	public Vendedor(Movil[] moviles, int totalV) {
		super();
		this.moviles = moviles;
		this.totalV = totalV;
	}
	
	//METODOS IMPORTANTES 
	public void add(Movil m,int posicion) {
		moviles[posicion]=m;
	}
	
	public void listarMov() {
		for (int i = 0; i < moviles.length; i++) {
			System.out.println((i+1)+ ". "+ moviles[i]);
		}
	}
	
	public int findByIdV2(String marca) {
		int i = 0;
		boolean encontrado = false;

		while (i < moviles.length && !encontrado) {
			Movil deLista = moviles[i];
			if (deLista.getMarca().equalsIgnoreCase(marca))
				encontrado = true;
			else
				i++;
		}
		if (encontrado)
			return i;
		else
			return -1;
	}
	
	public void editPrecio(String marca, float precioN) {
		int index = findByIdV2(marca);
		if (index >= 0) {
			moviles[index].setPrecioUni(precioN);
			
		} 

	}
	
	
	
	
	


	

	
	public Movil[] getMoviles() {
		return moviles;
	}
	public void setMoviles(Movil[] moviles) {
		this.moviles = moviles;
	}
	public int getTotalV() {
		return totalV;
	}
	public void setTotalV(int totalV) {
		this.totalV = totalV;
	}
	@Override
	public String toString() {
		return "Vendedor [moviles=" + Arrays.toString(moviles) + ", totalV=" + totalV + "]";
	}
	
	

	
	

}
