package examena;

import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pasteleria tarta;
		String sabor;
		int tam=0, eleccionExtra=0, opcion=0, cero=0, hasta=0, desde=0;
		double precioLitro=0.0, volumen=0.0, porcenGan=0.0, costeExtra=0.0;
		boolean extraNormal;
		int[] cantTartas;
		
		System.out.println("bienvenidos al programa");
		System.out.println("indica los dias que vamos a contabilizar");
		tam=Leer.datoInt();
		cantTartas=new int[tam];
		System.out.println("indique el sabor");
		sabor=Leer.dato();
		System.out.println("inidca el precio en euros que se usa para elaborar una tarta");
		precioLitro=Leer.datoDouble();
		System.out.println("indica el volumen en litros que se usa para una tarta");
		volumen=Leer.datoDouble();
		System.out.println("pulse 1: extra\n"
				+ "pulse 2: no extra");
		eleccionExtra=Leer.datoInt();
		
		
		
		

	}

}
